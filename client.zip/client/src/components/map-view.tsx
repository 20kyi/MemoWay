import { useEffect, useRef, useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Search, X, MapPin, Plane, Heart, Utensils, Coffee, ShoppingBag, Dumbbell, Briefcase, Filter, Users, Lock, Unlock } from "lucide-react";
import { loadKakaoMaps } from "@/lib/kakao-maps";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/lib/language-context";
import type { MemoWithDetails, GroupWithMembers } from "@shared/schema";

interface MapViewProps {
  onLocationSelect: (location: { lat: number; lng: number; address: string; buildingName: string }) => void;
  memos: MemoWithDetails[];
  onMarkerClick: (memoId: string) => void;
  onClusterClick?: (memoIds: string[]) => void;
  userLocation: { lat: number; lng: number } | null;
  onMapReady?: (map: any) => void;
  onMyLocationClick?: (location: { lat: number; lng: number }) => void;
  pendingLocation?: { lat: number; lng: number } | null;
  groups?: GroupWithMembers[];
  selectedMarkerIcons?: string[];
  selectedGroupIds?: string[];
  onMarkerIconsChange?: (icons: string[]) => void;
  onGroupIdsChange?: (groupIds: string[]) => void;
}

const PERSONAL_MEMO_COLOR = '#9333ea';

interface MemoCluster {
  key: string;
  memos: MemoWithDetails[];
  lat: number;
  lng: number;
}

function groupMemosByLocation(memos: MemoWithDetails[]): MemoCluster[] {
  const grouped = new Map<string, MemoWithDetails[]>();
  
  memos.forEach(memo => {
    const lat = memo.latitude.toFixed(6);
    const lng = memo.longitude.toFixed(6);
    const key = `${lat},${lng}`;
    
    if (!grouped.has(key)) {
      grouped.set(key, []);
    }
    grouped.get(key)!.push(memo);
  });
  
  return Array.from(grouped.entries()).map(([key, clusterMemos]) => ({
    key,
    memos: clusterMemos,
    lat: clusterMemos[0].latitude,
    lng: clusterMemos[0].longitude,
  }));
}

function getMarkerIconPath(iconType: string): string {
  switch (iconType) {
    case 'travel':
      return 'M12 2L10.5 6H6l4 3.5L8 15l4-2.5L16 15l-2-5.5L18 6h-4.5L12 2z M15 17v6h-3v-6h3z';
    case 'love':
      return 'M15 20c-3.9-3.5-7-6.3-7-9.5C8 8 9.8 6 12 6c1.1 0 2.2.5 3 1.3C15.8 6.5 16.9 6 18 6c2.2 0 4 1.8 4 4.5 0 3.2-3.1 6-7 9.5z';
    case 'food':
      return 'M13 3v8h-2V3h2z M19 3v4c0 2.2-1.8 4-4 4v14h-2V11c-2.2 0-4-1.8-4-4V3h2v4c0 1.1.9 2 2 2s2-.9 2-2V3h2z';
    case 'cafe':
      return 'M20 8h-3V4H7v10c0 2.2 1.8 4 4 4h2c2.2 0 4-1.8 4-4v-2h3c1.1 0 2-.9 2-2s-.9-2-2-2zM20 10h-3V10h3z M7 22h12v2H7z';
    case 'shopping':
      return 'M19 6h-2c0-2.8-2.2-5-5-5S7 3.2 7 6H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zM12 3c1.7 0 3 1.3 3 3H9c0-1.7 1.3-3 3-3z';
    case 'sport':
      return 'M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8zm-1-13h2v6h-2V7zm0 8h2v2h-2v-2z';
    case 'work':
      return 'M20 7h-4V5c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v2H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zM14 7h-4V5h4v2z';
    default:
      return 'M15 12c0 1.7-1.3 3-3 3s-3-1.3-3-3 1.3-3 3-3 3 1.3 3 3z';
  }
}

function createMarkerContent(color: string, iconType: string = 'default', photoUrl?: string, scale: number = 1): string {
  const iconPath = getMarkerIconPath(iconType);
  const width = 30 * scale;
  const height = 40 * scale;
  
  // If photo is provided, create photo marker
  if (photoUrl) {
    const clipId = `photoClip-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    return `
      <div 
        style="
          position: relative;
          width: ${width}px;
          height: ${height}px;
          cursor: pointer;
        "
        data-marker-icon="${iconType}"
        aria-label="${iconType} 마커"
      >
        <svg width="${width}" height="${height}" viewBox="0 0 30 40" xmlns="http://www.w3.org/2000/svg" style="pointer-events: none;">
          <defs>
            <clipPath id="${clipId}">
              <circle cx="15" cy="15" r="8"/>
            </clipPath>
          </defs>
          <path d="M15 0C6.716 0 0 6.716 0 15c0 8.284 15 25 15 25s15-16.716 15-25C30 6.716 23.284 0 15 0z" 
                fill="${color}" 
                stroke="#ffffff" 
                stroke-width="2"/>
          <circle cx="15" cy="15" r="8.5" fill="#ffffff"/>
          <image href="${photoUrl}" x="7" y="7" width="16" height="16" clip-path="url(#${clipId})" preserveAspectRatio="xMidYMid slice"/>
        </svg>
        <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; cursor: pointer;" data-click-area="true"></div>
      </div>
    `;
  }
  
  // Icon marker (no photo)
  return `
    <div 
      style="
        position: relative;
        width: ${width}px;
        height: ${height}px;
        cursor: pointer;
      "
      data-marker-icon="${iconType}"
      aria-label="${iconType} 마커"
    >
      <svg width="${width}" height="${height}" viewBox="0 0 30 40" xmlns="http://www.w3.org/2000/svg" style="pointer-events: none;">
        <path d="M15 0C6.716 0 0 6.716 0 15c0 8.284 15 25 15 25s15-16.716 15-25C30 6.716 23.284 0 15 0z" 
              fill="${color}" 
              stroke="#ffffff" 
              stroke-width="2"/>
        <circle cx="15" cy="15" r="8" fill="#ffffff"/>
        <g transform="translate(6, 6)" fill="${color}">
          <path d="${iconPath}" />
        </g>
      </svg>
      <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; cursor: pointer;" data-click-area="true"></div>
    </div>
  `;
}

function createClusterMarkerContent(color: string, count: number, iconType: string = 'default', photoUrl?: string, scale: number = 1): string {
  const iconPath = getMarkerIconPath(iconType);
  const width = 30 * scale;
  const height = 40 * scale;
  const badgeSize = 20 * scale;
  const fontSize = 10 * scale;
  const badgeTop = -7 * scale;
  const badgeRight = -7 * scale;
  
  // If photo is provided, create photo marker with count badge
  if (photoUrl) {
    const clipId = `photoClipCluster-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    return `
      <div 
        style="
          position: relative;
          width: ${width}px;
          height: ${height}px;
          cursor: pointer;
        "
        data-marker-icon="${iconType}"
        data-marker-count="${count}"
        aria-label="${iconType} 마커 클러스터 (${count}개)"
      >
        <svg width="${width}" height="${height}" viewBox="0 0 30 40" xmlns="http://www.w3.org/2000/svg" style="pointer-events: none;">
          <defs>
            <clipPath id="${clipId}">
              <circle cx="15" cy="15" r="8"/>
            </clipPath>
          </defs>
          <path d="M15 0C6.716 0 0 6.716 0 15c0 8.284 15 25 15 25s15-16.716 15-25C30 6.716 23.284 0 15 0z" 
                fill="${color}" 
                stroke="#ffffff" 
                stroke-width="2"/>
          <circle cx="15" cy="15" r="8.5" fill="#ffffff"/>
          <image href="${photoUrl}" x="7" y="7" width="16" height="16" clip-path="url(#${clipId})" preserveAspectRatio="xMidYMid slice"/>
        </svg>
        <div style="
          position: absolute;
          top: ${badgeTop}px;
          right: ${badgeRight}px;
          background-color: #ef4444;
          color: white;
          border-radius: 50%;
          width: ${badgeSize}px;
          height: ${badgeSize}px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: ${fontSize}px;
          font-weight: bold;
          border: ${2 * scale}px solid white;
          box-shadow: 0 2px 6px rgba(0,0,0,0.3);
          pointer-events: none;
        ">${count}</div>
        <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; cursor: pointer;" data-click-area="true"></div>
      </div>
    `;
  }
  
  return `
    <div 
      style="
        position: relative;
        width: ${width}px;
        height: ${height}px;
        cursor: pointer;
      "
      data-marker-icon="${iconType}"
      data-marker-count="${count}"
      aria-label="${iconType} 마커 클러스터 (${count}개)"
    >
      <svg width="${width}" height="${height}" viewBox="0 0 30 40" xmlns="http://www.w3.org/2000/svg" style="pointer-events: none;">
        <path d="M15 0C6.716 0 0 6.716 0 15c0 8.284 15 25 15 25s15-16.716 15-25C30 6.716 23.284 0 15 0z" 
              fill="${color}" 
              stroke="#ffffff" 
              stroke-width="2"/>
        <circle cx="15" cy="15" r="8" fill="#ffffff"/>
        <g transform="translate(6, 6)" fill="${color}">
          <path d="${iconPath}" />
        </g>
      </svg>
      <div style="
        position: absolute;
        top: ${badgeTop}px;
        right: ${badgeRight}px;
        background-color: #ef4444;
        color: white;
        border-radius: 50%;
        width: ${badgeSize}px;
        height: ${badgeSize}px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: ${fontSize}px;
        font-weight: bold;
        border: ${2 * scale}px solid white;
        box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        pointer-events: none;
      ">${count}</div>
      <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; cursor: pointer;" data-click-area="true"></div>
    </div>
  `;
}

function createSearchMarkerContent(): string {
  return `
    <div style="
      position: relative;
      width: 40px;
      height: 50px;
      animation: bounce 1s ease-in-out 3;
    ">
      <svg width="40" height="50" viewBox="0 0 40 50" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" flood-opacity="0.3"/>
          </filter>
        </defs>
        <path d="M20 0C11.163 0 4 7.163 4 16c0 12 16 34 16 34s16-22 16-34C36 7.163 28.837 0 20 0z" 
              fill="#ef4444" 
              stroke="#ffffff" 
              stroke-width="3"
              filter="url(#shadow)"/>
        <circle cx="20" cy="16" r="7" fill="#ffffff"/>
        <circle cx="20" cy="16" r="4" fill="#ef4444"/>
      </svg>
    </div>
    <style>
      @keyframes bounce {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
      }
    </style>
  `;
}

const MARKER_ICON_COMPONENTS = {
  default: MapPin,
  travel: Plane,
  love: Heart,
  food: Utensils,
  cafe: Coffee,
  shopping: ShoppingBag,
  sport: Dumbbell,
  work: Briefcase,
};

export function MapView({ 
  onLocationSelect, 
  memos, 
  onMarkerClick, 
  onClusterClick, 
  userLocation, 
  onMapReady,
  onMyLocationClick,
  pendingLocation,
  groups = [],
  selectedMarkerIcons = ["all"],
  selectedGroupIds = ["all"],
  onMarkerIconsChange,
  onGroupIdsChange
}: MapViewProps) {
  const { t } = useLanguage();
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<any>(null);
  const [searchMarker, setSearchMarker] = useState<any>(null);
  const [mapError, setMapError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [isMapLocked, setIsMapLocked] = useState(false);
  const [currentUserLocation, setCurrentUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocationLocked, setIsLocationLocked] = useState(true); // 위치 고정 모드 (기본값: true)
  const [markers, setMarkers] = useState<Array<{ overlay: any; handler?: (e: MouseEvent) => void; contentDiv?: HTMLElement; topDiv?: HTMLElement | null; memoId?: string; memoIds?: string[] }>>([]);
  const [markerFilterOpen, setMarkerFilterOpen] = useState(false);
  const [groupFilterOpen, setGroupFilterOpen] = useState(false);
  const watchIdRef = useRef<number | null>(null);
  const { toast } = useToast();

  // Filter memos based on selected marker icons and groups
  const filteredMemos = useMemo(() => {
    let filtered = memos;

    // Filter by marker icon
    if (!selectedMarkerIcons.includes("all")) {
      filtered = filtered.filter(memo => selectedMarkerIcons.includes(memo.markerIcon));
    }

    // Filter by group
    if (!selectedGroupIds.includes("all")) {
      filtered = filtered.filter(memo => {
        if (selectedGroupIds.includes("personal") && !memo.groupId) {
          return true;
        }
        if (memo.groupId && selectedGroupIds.includes(memo.groupId)) {
          return true;
        }
        return false;
      });
    }

    return filtered;
  }, [memos, selectedMarkerIcons, selectedGroupIds]);

  // Cleanup search marker when component unmounts
  useEffect(() => {
    return () => {
      if (searchMarker) {
        searchMarker.setMap(null);
      }
    };
  }, [searchMarker]);

  // Initialize map only once
  useEffect(() => {
    if (!mapRef.current) return;
    
    // 이미 지도가 초기화되었으면 무시
    if (map) return;

    let isMounted = true; // 컴포넌트가 마운트되어 있는지 확인

    loadKakaoMaps()
      .then(() => {
        // 컴포넌트가 언마운트되었거나 이미 지도가 있으면 무시
        if (!isMounted || !mapRef.current || !window.kakao?.maps || map) {
          return;
        }

        const container = mapRef.current;
        if (!container) return;

        const options = {
          center: new window.kakao.maps.LatLng(37.5665, 126.9780),
          level: 3,
          draggable: true, // 지도 드래그 활성화
          scrollwheel: true, // 마우스 휠 줌 활성화
          disableDoubleClick: false, // 더블클릭 줌 활성화
          disableDoubleClickZoom: false, // 더블클릭 줌 활성화
        };

        try {
          const kakaoMap = new window.kakao.maps.Map(container, options);
          
          // 다시 한 번 마운트 상태 확인
          if (!isMounted) {
            return;
          }
          
          setMap(kakaoMap);
          
          // 모바일 터치 이벤트 지원을 위한 추가 설정
          container.style.touchAction = 'pan-x pan-y pinch-zoom';
          
          // Notify parent that map is ready
          if (onMapReady) {
            onMapReady(kakaoMap);
          }
        } catch (error) {
          console.error("지도 초기화 실패:", error);
          if (isMounted) {
            setMapError("지도를 초기화할 수 없습니다. 페이지를 새로고침해주세요.");
          }
        }
      })
      .catch((error) => {
        console.error("Failed to load Kakao Maps:", error);
        if (isMounted) {
          setMapError("지도를 불러올 수 없습니다. API 키를 확인해주세요.");
        }
      });

    return () => {
      isMounted = false; // 컴포넌트 언마운트 시 플래그 설정
    };
  }, [map, onMapReady]);

  // Auto-move to user location when map first loads
  const hasMovedToUserLocationRef = useRef(false);
  const gpsAttemptCountRef = useRef(0);
  const MAX_GPS_ATTEMPTS = 3;
  const DESIRED_ACCURACY = 30; // meters

  useEffect(() => {
    // pendingLocation이 있으면 자동 위치 이동을 건너뜀
    if (!map || hasMovedToUserLocationRef.current || pendingLocation) return;

    const tryGetAccuratePosition = () => {
      if (navigator.geolocation && gpsAttemptCountRef.current < MAX_GPS_ATTEMPTS) {
        gpsAttemptCountRef.current += 1;
        
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const accuracy = position.coords.accuracy;
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            
            console.log(`GPS 시도 ${gpsAttemptCountRef.current}/${MAX_GPS_ATTEMPTS}: 정밀도 ${Math.round(accuracy)}m`);
            
            // 정밀도가 30m 이하인 경우에만 사용
            if (accuracy <= DESIRED_ACCURACY) {
              const latlng = new window.kakao.maps.LatLng(lat, lng);
              map.setCenter(latlng);
              map.setLevel(3);
              hasMovedToUserLocationRef.current = true;
              
              console.log(`정확한 위치 획득: ${Math.round(accuracy)}m 정밀도`);
              
              // Also notify parent about user location
              if (onMyLocationClick) {
                onMyLocationClick({ lat, lng });
              }
            } else if (gpsAttemptCountRef.current < MAX_GPS_ATTEMPTS) {
              // 정밀도가 충분하지 않으면 다시 시도
              console.log(`정밀도 부족(${Math.round(accuracy)}m > 30m), 재시도...`);
              setTimeout(tryGetAccuratePosition, 1000);
            } else {
              // 최대 시도 횟수 도달, 현재 위치라도 사용
              console.log(`최대 시도 횟수 도달, 현재 위치 사용: ${Math.round(accuracy)}m 정밀도`);
              const latlng = new window.kakao.maps.LatLng(lat, lng);
              map.setCenter(latlng);
              map.setLevel(3);
              hasMovedToUserLocationRef.current = true;
              
              if (onMyLocationClick) {
                onMyLocationClick({ lat, lng });
              }
            }
          },
          (error) => {
            console.log("위치 정보를 가져올 수 없습니다:", error);
            // If geolocation fails and we have userLocation, use it
            if (userLocation && !hasMovedToUserLocationRef.current) {
              const position = new window.kakao.maps.LatLng(userLocation.lat, userLocation.lng);
              map.setCenter(position);
              map.setLevel(3);
              hasMovedToUserLocationRef.current = true;
            }
          },
          {
            enableHighAccuracy: true,
            timeout: 10000, // 10초로 증가
            maximumAge: 0,
          }
        );
      } else if (userLocation && !hasMovedToUserLocationRef.current) {
        // Fallback to userLocation prop if geolocation not available
        const position = new window.kakao.maps.LatLng(userLocation.lat, userLocation.lng);
        map.setCenter(position);
        map.setLevel(3);
        hasMovedToUserLocationRef.current = true;
      }
    };

    tryGetAccuratePosition();
  }, [map, userLocation, onMyLocationClick, pendingLocation]);

  // pendingLocation이 처리되면 자동 위치 이동을 막고 위치 고정 모드 해제
  useEffect(() => {
    if (pendingLocation && map) {
      hasMovedToUserLocationRef.current = true;
      // pendingLocation이 있으면 위치 고정 모드를 해제하여 메모 위치로 이동할 수 있도록 함
      if (isLocationLocked) {
        setIsLocationLocked(false);
      }
    }
  }, [pendingLocation, map, isLocationLocked]);

  // Update marker scale based on zoom level

  // Detect user dragging the map and disable location lock
  const isDraggingRef = useRef(false);
  
  useEffect(() => {
    if (!map || !window.kakao?.maps) return;

    const handleDragStart = () => {
      isDraggingRef.current = true; // 드래그 시작 플래그 설정
      if (isLocationLocked) {
        setIsLocationLocked(false);
      }
    };

    const handleDragEnd = () => {
      // 드래그 종료 후 약간의 지연을 두고 플래그 해제 (클릭 이벤트와 충돌 방지)
      setTimeout(() => {
        isDraggingRef.current = false;
      }, 100);
    };

    const handleZoomStart = () => {
      if (isLocationLocked) {
        setIsLocationLocked(false);
      }
    };

    const handleZoomChanged = () => {
      // 줌 변경 처리 (필요시 추가)
    };

    window.kakao.maps.event.addListener(map, 'dragstart', handleDragStart);
    window.kakao.maps.event.addListener(map, 'dragend', handleDragEnd);
    window.kakao.maps.event.addListener(map, 'zoom_start', handleZoomStart);
    window.kakao.maps.event.addListener(map, 'zoom_changed', handleZoomChanged);

    return () => {
      window.kakao.maps.event.removeListener(map, 'dragstart', handleDragStart);
      window.kakao.maps.event.removeListener(map, 'dragend', handleDragEnd);
      window.kakao.maps.event.removeListener(map, 'zoom_start', handleZoomStart);
      window.kakao.maps.event.removeListener(map, 'zoom_changed', handleZoomChanged);
    };
  }, [map, isLocationLocked]);

  // Register map click handler with fresh memos
  useEffect(() => {
    if (!map || !window.kakao?.maps) return;

    const handleMapClick = (mouseEvent: any) => {
      // 드래그 중이면 클릭 이벤트 무시 (성능 최적화)
      if (isDraggingRef.current) {
        return;
      }
      
      const latlng = mouseEvent.latLng;
      if (!latlng) {
        console.warn('Map click event has no latLng');
        return;
      }
      const clickLat = latlng.getLat();
      const clickLng = latlng.getLng();
      
      // 지도 클릭 처리
      // 마커 클릭 이벤트가 먼저 처리되도록 약간의 지연
      setTimeout(() => {
        // 드래그 중이면 클릭 처리 중단
        if (isDraggingRef.current) {
          return;
        }
        // 마커 위치와 클릭 위치 비교 (더 정확한 거리 계산)
        const clickPosition = new window.kakao.maps.LatLng(clickLat, clickLng);
        const clickedMarker = markers.find(marker => {
          if (!marker.overlay) return false;
          try {
            const markerPosition = marker.overlay.getPosition();
            if (!markerPosition) return false;
            // getLat, getLng 메서드가 존재하는지 확인
            if (typeof markerPosition.getLat !== 'function' || typeof markerPosition.getLng !== 'function') {
              return false;
            }
            const distance = Math.sqrt(
              Math.pow(clickPosition.getLat() - markerPosition.getLat(), 2) +
              Math.pow(clickPosition.getLng() - markerPosition.getLng(), 2)
            );
            // 마커 크기를 고려하여 더 넓은 범위로 감지 (약 50m)
            return distance < 0.0005;
          } catch (error) {
            // 마커 위치를 가져오는 중 오류 발생 시 무시
            console.warn('Error getting marker position:', error);
            return false;
          }
        });

        if (clickedMarker) {
          // 마커가 클릭된 것으로 간주 - 지도 클릭 처리 중단
          return;
        }
        
        console.log(' *** 지도 클릭됨 ***', { lat: clickLat, lng: clickLng });
        
        // 먼저 geocoding을 수행하여 도로명 주소를 가져온 후 비교
        const geocoder = new window.kakao.maps.services.Geocoder();
        
        geocoder.coord2Address(clickLng, clickLat, function(result: any, status: any) {
        if (status === window.kakao.maps.services.Status.OK && result && result.length > 0) {
          // 도로명 주소 우선, 없으면 지번 주소 사용
          const roadAddress = result[0]?.road_address?.address_name;
          const jibunAddress = result[0]?.address?.address_name;
          const address = roadAddress || jibunAddress || '주소 없음';
          const buildingName = result[0]?.road_address?.building_name || '건물명 없음';
          
          console.log('=== 지도 클릭 주소 비교 ===');
          console.log('클릭한 위치의 주소 (도로명):', roadAddress);
          console.log('클릭한 위치의 주소 (지번):', jibunAddress);
          console.log('사용할 주소:', address);
          console.log('전체 geocoding 결과:', JSON.stringify(result[0], null, 2));
          
          // 주소 정규화 함수 (시/도 표기 통일 + 공백 정리)
          const normalizeAddress = (addr: string): string => {
            if (!addr) return '';
            // 연속된 공백을 하나로 통일하고 앞뒤 공백 제거
            let normalized = addr.trim().replace(/\s+/g, ' ');
            
            // 시/도 표기 통일 (저장된 데이터가 일관성이 없어서 통일 필요)
            normalized = normalized
              .replace(/경기도/g, '경기')
              .replace(/서울특별시/g, '서울')
              .replace(/부산광역시/g, '부산')
              .replace(/대구광역시/g, '대구')
              .replace(/인천광역시/g, '인천')
              .replace(/광주광역시/g, '광주')
              .replace(/대전광역시/g, '대전')
              .replace(/울산광역시/g, '울산')
              .replace(/세종특별자치시/g, '세종')
              .replace(/제주특별자치도/g, '제주')
              .replace(/제주도/g, '제주')
              .replace(/전라북도/g, '전북')
              .replace(/전라남도/g, '전남')
              .replace(/경상북도/g, '경북')
              .replace(/경상남도/g, '경남')
              .replace(/충청북도/g, '충북')
              .replace(/충청남도/g, '충남')
              .replace(/강원특별자치도/g, '강원')
              .replace(/강원도/g, '강원');
            
            return normalized;
          };
          
          // 건물명 정규화 함수
          const normalizeBuildingName = (name: string): string => {
            if (!name) return '';
            // 연속된 공백을 하나로 통일하고 앞뒤 공백 제거
            return name.trim().replace(/\s+/g, ' ');
          };
          
          const normalizedAddress = normalizeAddress(address);
          const normalizedBuildingName = normalizeBuildingName(buildingName);
          console.log('클릭한 위치의 정규화된 주소:', `"${normalizedAddress}"`);
          console.log('클릭한 위치의 정규화된 주소 (길이):', normalizedAddress.length);
          console.log('클릭한 위치의 정규화된 주소 (문자 코드):', Array.from(normalizedAddress).map(c => c.charCodeAt(0)));
          console.log('클릭한 위치의 정규화된 건물명:', `"${normalizedBuildingName}"`);
          
          // 모든 메모의 주소와 건물명 확인
          console.log('저장된 모든 메모 (총', memos.length, '개):');
          memos.forEach((memo, index) => {
            const normalizedMemoAddress = normalizeAddress(memo.address);
            const normalizedMemoBuildingName = normalizeBuildingName(memo.buildingName);
            const addressMatch = normalizedAddress === normalizedMemoAddress;
            const buildingMatch = normalizedBuildingName === normalizedMemoBuildingName;
            const isMatch = addressMatch && buildingMatch;
            
            console.log(`[${index}] 메모 ID: ${memo.id}`);
            console.log(`  - 원본 주소: "${memo.address}"`);
            console.log(`  - 정규화 주소: "${normalizedMemoAddress}"`);
            console.log(`  - 정규화 주소 (길이): ${normalizedMemoAddress.length}`);
            console.log(`  - 정규화 주소 (문자 코드):`, Array.from(normalizedMemoAddress).map(c => c.charCodeAt(0)));
            console.log(`  - 비교 대상 주소: "${normalizedAddress}"`);
            console.log(`  - 주소 일치: ${addressMatch ? '✓' : '✗'}`);
            if (!addressMatch) {
              console.log(`  - 주소 불일치 원인 분석:`);
              console.log(`    - 길이 비교: ${normalizedAddress.length} vs ${normalizedMemoAddress.length}`);
              console.log(`    - 첫 10자 비교: "${normalizedAddress.substring(0, 10)}" vs "${normalizedMemoAddress.substring(0, 10)}"`);
              console.log(`    - 마지막 10자 비교: "${normalizedAddress.slice(-10)}" vs "${normalizedMemoAddress.slice(-10)}"`);
            }
            console.log(`  - 원본 건물명: "${memo.buildingName}"`);
            console.log(`  - 정규화 건물명: "${normalizedMemoBuildingName}"`);
            console.log(`  - 건물명 일치: ${buildingMatch ? '✓' : '✗'}`);
            console.log(`  - 전체 일치: ${isMatch ? '✓ 매칭!' : '✗ 불일치'}`);
          });
          
          // 같은 주소와 건물명을 가진 메모 찾기 (정확히 일치하는 경우만)
          console.log('\n주소 + 건물명 비교 시작 (둘 다 정확히 일치하는 경우만):');
          const memosAtLocation = memos.filter(memo => {
            const normalizedMemoAddress = normalizeAddress(memo.address);
            const normalizedMemoBuildingName = normalizeBuildingName(memo.buildingName);
            const isMatch = normalizedAddress === normalizedMemoAddress && 
                          normalizedBuildingName === normalizedMemoBuildingName;
            if (isMatch) {
              console.log(`✓ 매칭된 메모 발견: "${memo.address}", "${memo.buildingName}"`);
            }
            return isMatch;
          });
          
          console.log('\n=== 비교 결과 ===');
          console.log('같은 주소 + 건물명의 메모:', memosAtLocation.length, '개');
          if (memosAtLocation.length > 0) {
            console.log('매칭된 메모들:');
            memosAtLocation.forEach(m => {
              console.log(`  - ${m.id}: "${m.address}", "${m.buildingName}"`);
            });
          } else {
            console.log('매칭된 메모가 없습니다.');
            console.log('클릭한 주소/건물명과 저장된 메모들의 주소/건물명을 비교해보세요.');
          }
          
          // 같은 주소에 메모가 있으면 저장된 메모 보여주기
          if (memosAtLocation.length > 0) {
            console.log('저장된 메모 발견 - 메모 열기');
            if (memosAtLocation.length === 1) {
              if (onMarkerClick) {
                onMarkerClick(memosAtLocation[0].id);
              }
            } else if (onClusterClick) {
              onClusterClick(memosAtLocation.map(m => m.id));
            } else {
              if (onMarkerClick) {
                onMarkerClick(memosAtLocation[0].id);
              }
            }
            return;
          }
          
          // 같은 주소에 메모가 없으면 새 메모 창 열기
          console.log('새 메모 입력 창 열기 (매칭되는 메모 없음)');
          onLocationSelect({
            lat: clickLat,
            lng: clickLng,
            address,
            buildingName,
          });
        } else {
          // Geocoding 실패 시 새 메모 창 열기
          console.log('Geocoding 실패 - 새 메모 입력 창 열기');
          onLocationSelect({
            lat: clickLat,
            lng: clickLng,
            address: `위도: ${clickLat.toFixed(6)}, 경도: ${clickLng.toFixed(6)}`,
            buildingName: '위치 선택됨',
          });
        }
      });
      }, 50); // 마커 클릭 확인을 위한 딜레이
    };

    window.kakao.maps.event.addListener(map, 'click', handleMapClick);

    return () => {
      window.kakao.maps.event.removeListener(map, 'click', handleMapClick);
    };
  }, [map, memos, markers, onLocationSelect, onMarkerClick, onClusterClick]);

  // Render markers for memos
  useEffect(() => {
    if (!map || !window.kakao?.maps) return;

    // Remove existing markers and their event listeners
    markers.forEach(marker => {
      if (marker.overlay) {
        // DOM 이벤트 리스너 제거
        if (marker.handler && marker.contentDiv) {
          marker.contentDiv.removeEventListener('click', marker.handler);
        }
        marker.overlay.setMap(null);
      }
    });

    // Create clusters for memos at same location
    const clusters = groupMemosByLocation(filteredMemos);
    
    const newMarkers = clusters.map(cluster => {
      // 좌표 유효성 검사
      if (typeof cluster.lat !== 'number' || typeof cluster.lng !== 'number' || 
          isNaN(cluster.lat) || isNaN(cluster.lng) ||
          !isFinite(cluster.lat) || !isFinite(cluster.lng)) {
        console.warn('Invalid cluster coordinates:', cluster);
        return null;
      }
      const position = new window.kakao.maps.LatLng(cluster.lat, cluster.lng);
      
      const isSingleMemo = cluster.memos.length === 1;
      const memo = cluster.memos[0];
      
      let markerColor: string;
      let markerIcon: string = 'default';
      let mainPhotoUrl: string | undefined;
      
      if (isSingleMemo) {
        markerColor = memo.group?.color || PERSONAL_MEMO_COLOR;
        markerIcon = (memo as any)?.markerIcon || (memo.group as any)?.markerIcon || 'default';
        
        // Get main photo URL if available
        const mainPhotoId = (memo as any).mainPhotoId;
        if (mainPhotoId && memo.photos && memo.photos.length > 0) {
          const mainPhoto = memo.photos.find((p: any) => p.id === mainPhotoId);
          mainPhotoUrl = mainPhoto?.url;
        }
      } else {
        const colors = cluster.memos.map(m => m.group?.color || PERSONAL_MEMO_COLOR);
        const uniqueColors = new Set(colors);
        markerColor = uniqueColors.size === 1 ? colors[0] : '#6b7280';
        
        const icons = cluster.memos.map(m => (m as any)?.markerIcon || (m.group as any)?.markerIcon || 'default');
        const uniqueIcons = new Set(icons);
        markerIcon = uniqueIcons.size === 1 ? icons[0] : 'default';
        
        // Find main memo and get its photo
        const mainMemo = cluster.memos.find((m: any) => m.isMainMemo);
        if (mainMemo) {
          const mainPhotoId = (mainMemo as any).mainPhotoId;
          if (mainPhotoId && mainMemo.photos && mainMemo.photos.length > 0) {
            const mainPhoto = mainMemo.photos.find((p: any) => p.id === mainPhotoId);
            mainPhotoUrl = mainPhoto?.url;
          }
        }
      }
      
      // content DOM 요소 생성
      const contentDiv = document.createElement('div');
      contentDiv.innerHTML = isSingleMemo 
        ? createMarkerContent(markerColor, markerIcon, mainPhotoUrl, 1)
        : createClusterMarkerContent(markerColor, cluster.memos.length, markerIcon, mainPhotoUrl, 1);
      
      // 마커 스타일 설정
      contentDiv.style.cursor = 'pointer';
      contentDiv.style.pointerEvents = 'auto';
      contentDiv.style.userSelect = 'none';
      contentDiv.style.zIndex = '10000';
      contentDiv.style.position = 'relative';
      // 모바일 터치 이벤트: 마커 클릭만 처리하고 드래그는 지도로 전파
      contentDiv.style.touchAction = 'manipulation'; // 터치 드래그는 지도로 전파
      
      // 드래그와 클릭 구분을 위한 변수
      let isDragging = false;
      const DRAG_THRESHOLD = 5; // 5px 이상 움직이면 드래그로 간주
      
      // 마커 클릭 핸들러
      const handleMarkerClick = (e: MouseEvent) => {
        // 드래그인 경우 클릭 처리하지 않음
        if (isDragging) {
          return;
        }
        
        console.log('🎯 마커 클릭 핸들러 호출됨', { 
          isSingleMemo, 
          memoId: isSingleMemo ? memo.id : cluster.memos.map(m => m.id),
          hasOnMarkerClick: !!onMarkerClick,
          hasOnClusterClick: !!onClusterClick
        });
        
        e.stopPropagation();
        e.preventDefault();
        e.cancelBubble = true; // IE 호환성
        
        if (isSingleMemo) {
          if (onMarkerClick) {
            console.log('✅ onMarkerClick 호출:', memo.id);
            onMarkerClick(memo.id);
          } else {
            console.warn('⚠️ onMarkerClick이 없습니다');
          }
        } else {
          if (onClusterClick) {
            console.log('✅ onClusterClick 호출:', cluster.memos.map(m => m.id));
            onClusterClick(cluster.memos.map(m => m.id));
          } else if (onMarkerClick) {
            console.log('✅ onMarkerClick 호출 (클러스터):', cluster.memos[0].id);
            onMarkerClick(cluster.memos[0].id);
          } else {
            console.warn('⚠️ onClusterClick과 onMarkerClick이 모두 없습니다');
          }
        }
      };
      
      // 드래그와 클릭 구분을 위한 핸들러 (마우스 + 터치 지원)
      // 성능 최적화: throttle 적용
      let mouseDownX = 0;
      let mouseDownY = 0;
      let touchStartX = 0;
      let touchStartY = 0;
      let lastMoveTime = 0;
      const MOVE_THROTTLE = 16; // ~60fps (16ms)
      
      const mouseDownHandler = (event: MouseEvent) => {
        mouseDownX = event.clientX;
        mouseDownY = event.clientY;
        isDragging = false;
      };
      
      const mouseMoveHandler = (event: MouseEvent) => {
        // 성능 최적화: throttle 적용
        const now = Date.now();
        if (now - lastMoveTime < MOVE_THROTTLE) {
          return;
        }
        lastMoveTime = now;
        
        const deltaX = Math.abs(event.clientX - mouseDownX);
        const deltaY = Math.abs(event.clientY - mouseDownY);
        if (deltaX > DRAG_THRESHOLD || deltaY > DRAG_THRESHOLD) {
          isDragging = true;
        }
      };
      
      // 터치 이벤트 핸들러 (모바일 지원)
      const touchStartHandler = (event: TouchEvent) => {
        if (event.touches.length === 1) {
          touchStartX = event.touches[0].clientX;
          touchStartY = event.touches[0].clientY;
          isDragging = false;
          lastMoveTime = Date.now();
        } else {
          // 멀티터치(핀치 줌 등)는 지도로 전파
          isDragging = true;
        }
      };
      
      const touchMoveHandler = (event: TouchEvent) => {
        // 성능 최적화: throttle 적용
        const now = Date.now();
        if (now - lastMoveTime < MOVE_THROTTLE) {
          return;
        }
        lastMoveTime = now;
        
        if (event.touches.length === 1) {
          const deltaX = Math.abs(event.touches[0].clientX - touchStartX);
          const deltaY = Math.abs(event.touches[0].clientY - touchStartY);
          if (deltaX > DRAG_THRESHOLD || deltaY > DRAG_THRESHOLD) {
            isDragging = true;
            // 드래그 중이면 이벤트 전파하여 지도가 드래그되도록 함
            event.stopPropagation();
          }
        } else {
          // 멀티터치는 지도로 전파
          isDragging = true;
        }
      };
      
      const touchEndHandler = (event: TouchEvent) => {
        // 드래그가 아닌 경우에만 클릭 처리
        if (!isDragging && event.changedTouches.length === 1) {
          console.log('👆 마커 터치 클릭 이벤트 발생', event);
          event.stopPropagation();
          event.preventDefault();
          handleMarkerClick(event as any);
        }
        // 리셋
        isDragging = false;
      };
      
      const clickHandler = (event: MouseEvent) => {
        // 드래그가 아닌 경우에만 클릭 처리
        if (!isDragging) {
          console.log('🖱️ 마커 클릭 이벤트 발생', event);
          event.stopPropagation();
          event.preventDefault();
          event.cancelBubble = true;
          handleMarkerClick(event);
        }
        // 리셋
        isDragging = false;
      };
      
      // innerHTML 설정 후 즉시 최상위 div를 찾아서 이벤트 등록
      const topDiv = contentDiv.firstElementChild as HTMLElement;
      if (topDiv) {
        // 마우스 이벤트
        topDiv.addEventListener('mousedown', mouseDownHandler);
        topDiv.addEventListener('mousemove', mouseMoveHandler);
        topDiv.addEventListener('click', clickHandler, true);
        topDiv.addEventListener('click', clickHandler, false);
        // 터치 이벤트 (모바일 지원)
        topDiv.addEventListener('touchstart', touchStartHandler, { passive: true });
        topDiv.addEventListener('touchmove', touchMoveHandler, { passive: true });
        topDiv.addEventListener('touchend', touchEndHandler, { passive: false });
        // 최상위 div에도 스타일 설정
        topDiv.style.cursor = 'pointer';
        topDiv.style.pointerEvents = 'auto';
        topDiv.style.touchAction = 'manipulation';
      }
      
      // contentDiv에도 이벤트 등록
      contentDiv.addEventListener('mousedown', mouseDownHandler);
      contentDiv.addEventListener('mousemove', mouseMoveHandler);
      contentDiv.addEventListener('click', clickHandler, true);
      contentDiv.addEventListener('click', clickHandler, false);
      // 터치 이벤트
      contentDiv.addEventListener('touchstart', touchStartHandler, { passive: true });
      contentDiv.addEventListener('touchmove', touchMoveHandler, { passive: true });
      contentDiv.addEventListener('touchend', touchEndHandler, { passive: false });
      
      // data-click-area div에도 이벤트 등록
      const clickArea = contentDiv.querySelector('[data-click-area="true"]') as HTMLElement;
      if (clickArea) {
        clickArea.addEventListener('mousedown', mouseDownHandler);
        clickArea.addEventListener('mousemove', mouseMoveHandler);
        clickArea.addEventListener('click', clickHandler, true);
        clickArea.addEventListener('click', clickHandler, false);
        // 터치 이벤트
        clickArea.addEventListener('touchstart', touchStartHandler, { passive: true });
        clickArea.addEventListener('touchmove', touchMoveHandler, { passive: true });
        clickArea.addEventListener('touchend', touchEndHandler, { passive: false });
        clickArea.style.pointerEvents = 'auto';
        clickArea.style.cursor = 'pointer';
        clickArea.style.touchAction = 'manipulation';
      }
      
      const customOverlay = new window.kakao.maps.CustomOverlay({
        position,
        content: contentDiv,
        yAnchor: 1,
        zIndex: 10000,
        clickable: true,
      });
      
      // 마커 객체 생성
      const markerObj = { 
        overlay: customOverlay,
        handler: clickHandler,
        contentDiv: contentDiv,
        topDiv: topDiv,
        memoId: isSingleMemo ? memo.id : undefined,
        memoIds: !isSingleMemo ? cluster.memos.map(m => m.id) : undefined,
      };
      
      customOverlay.setMap(map);
      
      // setMap 후에도 한 번 더 확인하여 이벤트 등록 (이중 보험)
      requestAnimationFrame(() => {
        const topDivAfter = contentDiv.firstElementChild as HTMLElement;
        if (topDivAfter) {
          topDivAfter.addEventListener('mousedown', mouseDownHandler);
          topDivAfter.addEventListener('mousemove', mouseMoveHandler);
          topDivAfter.addEventListener('click', clickHandler, true);
          topDivAfter.addEventListener('click', clickHandler, false);
          topDivAfter.addEventListener('touchstart', touchStartHandler, { passive: true });
          topDivAfter.addEventListener('touchmove', touchMoveHandler, { passive: true });
          topDivAfter.addEventListener('touchend', touchEndHandler, { passive: false });
        }
        
        const clickAreaAfter = contentDiv.querySelector('[data-click-area="true"]') as HTMLElement;
        if (clickAreaAfter) {
          clickAreaAfter.addEventListener('mousedown', mouseDownHandler);
          clickAreaAfter.addEventListener('mousemove', mouseMoveHandler);
          clickAreaAfter.addEventListener('click', clickHandler, true);
          clickAreaAfter.addEventListener('click', clickHandler, false);
          clickAreaAfter.addEventListener('touchstart', touchStartHandler, { passive: true });
          clickAreaAfter.addEventListener('touchmove', touchMoveHandler, { passive: true });
          clickAreaAfter.addEventListener('touchend', touchEndHandler, { passive: false });
        }
      });
      
      return markerObj;
    }).filter((marker): marker is NonNullable<typeof marker> => marker !== null);

    setMarkers(newMarkers);

    return () => {
      newMarkers.forEach(marker => {
        if (marker && marker.overlay) {
          // overlay를 제거하면 자동으로 모든 이벤트 리스너가 정리됨
          marker.overlay.setMap(null);
        }
      });
    };
  }, [map, filteredMemos, onMarkerClick, onClusterClick]);

  // Start watching user's real-time location
  useEffect(() => {
    if (!map || !navigator.geolocation) return;

    let lastUpdateTime = 0;
    let lastLat: number | null = null;
    let lastLng: number | null = null;
    const MIN_UPDATE_INTERVAL = 1000; // 최소 업데이트 간격: 1초
    const MIN_DISTANCE_CHANGE = 0.0001; // 최소 거리 변화: 약 10m (도 단위)

    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        const now = Date.now();
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        
        // 시간 기반 필터링: 최소 업데이트 간격 체크
        if (now - lastUpdateTime < MIN_UPDATE_INTERVAL) {
          return;
        }

        // 거리 기반 필터링: 위치가 충분히 변했는지 체크
        if (lastLat !== null && lastLng !== null) {
          const distance = Math.sqrt(
            Math.pow(lat - lastLat, 2) + Math.pow(lng - lastLng, 2)
          );
          if (distance < MIN_DISTANCE_CHANGE) {
            return; // 위치 변화가 미미하면 업데이트 건너뛰기
          }
        }

        // 위치 업데이트
        lastUpdateTime = now;
        lastLat = lat;
        lastLng = lng;
        
        setCurrentUserLocation({ lat, lng });
        
        // If location is locked, center map on user location
        // pendingLocation이 있으면 자동 위치 이동을 막음
        if (isLocationLocked && !pendingLocation) {
          const latlng = new window.kakao.maps.LatLng(lat, lng);
          map.panTo(latlng); // Smooth pan to location
        }
        
        // Notify parent component (위치가 실제로 변경되었을 때만)
        if (onMyLocationClick) {
          onMyLocationClick({ lat, lng });
        }
      },
      (error) => {
        console.log("실시간 위치 추적 오류:", error);
      },
      {
        // 위치 고정 모드일 때만 고정밀도 사용 (배터리 절약)
        enableHighAccuracy: isLocationLocked,
        // 타임아웃 증가로 재시도 빈도 감소
        timeout: isLocationLocked ? 15000 : 10000,
        // 캐시된 위치 정보 활용 (5초 이내 캐시 허용)
        maximumAge: 5000,
      }
    );

    watchIdRef.current = watchId;

    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
    };
  }, [map, onMyLocationClick, isLocationLocked, pendingLocation]);

  // When location is NOT locked, display user location marker on map
  useEffect(() => {
    if (!map || !currentUserLocation || isLocationLocked) return;

    const position = new window.kakao.maps.LatLng(currentUserLocation.lat, currentUserLocation.lng);

    // User 아이콘 마커
    const markerContent = document.createElement('div');
    markerContent.innerHTML = `
      <div style="
        position: relative;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #3b82f6;
        border-radius: 50%;
        border: 2px solid #ffffff;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
        cursor: default;
        transition: all 0.3s ease-out;
      ">
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          width="18" 
          height="18" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="#ffffff" 
          stroke-width="2.5" 
          stroke-linecap="round" 
          stroke-linejoin="round"
        >
          <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/>
          <circle cx="12" cy="7" r="4"/>
        </svg>
      </div>
    `;

    const userMarker = new window.kakao.maps.CustomOverlay({
      position: position,
      content: markerContent,
      yAnchor: 0.5,
    });
    
    userMarker.setMap(map);

    return () => {
      userMarker.setMap(null);
    };
  }, [map, currentUserLocation, isLocationLocked]);

  const handleMyLocation = () => {
    if (navigator.geolocation && map) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          const latlng = new window.kakao.maps.LatLng(lat, lng);
          map.setCenter(latlng);
          // 내 위치 버튼 클릭 시 위치 고정 모드 활성화
          setIsLocationLocked(true);
        },
        (error) => {
          console.log("현재 위치 가져오기 오류:", error);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 30000, // 30초 이내 캐시 허용
        }
      );
    }
  };

  const handleSearchAddress = () => {
    if (!searchQuery.trim() || !map || !window.kakao?.maps) return;

    setIsSearching(true);
    const geocoder = new window.kakao.maps.services.Geocoder();

    geocoder.addressSearch(searchQuery, (result: any, status: any) => {
      setIsSearching(false);

      if (status === window.kakao.maps.services.Status.OK && result && result.length > 0) {
        if (!result || result.length === 0 || !result[0] || result[0].x === undefined || result[0].y === undefined) {
          toast({
            title: "오류",
            description: "주소를 찾을 수 없습니다",
            variant: "destructive",
          });
          return;
        }
        const coords = new window.kakao.maps.LatLng(result[0].y, result[0].x);
        
        // Remove previous search marker if exists
        if (searchMarker) {
          searchMarker.setMap(null);
        }

        // Create search marker
        const markerContent = document.createElement('div');
        markerContent.innerHTML = createSearchMarkerContent();
        
        const customOverlay = new window.kakao.maps.CustomOverlay({
          position: coords,
          content: markerContent,
          yAnchor: 1,
        });
        
        customOverlay.setMap(map);
        setSearchMarker(customOverlay);
        
        map.setCenter(coords);
        map.setLevel(3);

        // 주소 검색 후 위치 고정 모드 해제하여 검색 위치 유지
        setIsLocationLocked(false);

        toast({
          title: "위치 찾기 완료",
          description: result[0].address_name || searchQuery,
        });
        
        setSearchQuery("");
      } else {
        toast({
          title: "주소를 찾을 수 없습니다",
          description: "다른 주소로 다시 시도해주세요",
          variant: "destructive",
        });
      }
    });
  };

  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearchAddress();
    }
  };

  const handleClearSearch = () => {
    setSearchQuery("");
  };

  const toggleMapLock = () => {
    if (!map) return;
    
    const newLockState = !isMapLocked;
    setIsMapLocked(newLockState);
    
    if (newLockState) {
      // 지도 고정: 줌만 비활성화 (드래그는 가능)
      map.setDraggable(true);
      map.setZoomable(false);
      toast({
        title: "지도 확대/축소 잠금",
        description: "지도를 움직일 수 있지만 확대/축소는 불가능합니다",
      });
    } else {
      // 지도 고정 해제: 드래그와 줌 활성화
      map.setDraggable(true);
      map.setZoomable(true);
      toast({
        title: "지도 확대/축소 잠금 해제",
        description: "지도를 자유롭게 움직이고 확대/축소할 수 있습니다",
      });
    }
  };

  return (
    <div className="relative w-full h-full">
      {mapError ? (
        <div className="w-full h-full flex items-center justify-center bg-muted p-8 text-center">
          <div>
            <p className="text-muted-foreground mb-4">{mapError}</p>
            <p className="text-sm text-muted-foreground">
              설정에서 Kakao Maps API 키를 추가하거나,<br />
              그룹과 메모 관리 기능을 사용해보세요.
            </p>
          </div>
        </div>
      ) : (
        <>
          <div ref={mapRef} className="w-full h-full" data-testid="map-container" />
          
          {/* 위치 고정 모드 상태 배너 */}
          {isLocationLocked && (
            <div className="absolute top-20 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
              <div className="bg-blue-500/90 backdrop-blur-sm text-white px-4 py-2 rounded-full shadow-lg border-2 border-blue-400 flex items-center gap-2 animate-pulse">
                <Lock className="h-4 w-4" />
                <span className="text-sm font-medium">위치 고정 모드 활성화</span>
              </div>
            </div>
          )}
          
          {/* 화면 중앙에 고정된 사용자 위치 마커 (위치 고정 모드일 때만 표시) */}
          {isLocationLocked && currentUserLocation && (
            <div 
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-40"
              style={{ marginTop: '-16px' }} // Adjust for marker height
            >
              <div className="relative w-8 h-8 flex items-center justify-center bg-blue-500 rounded-full border-2 border-white shadow-lg">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="18" 
                  height="18" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="#ffffff" 
                  strokeWidth="2.5" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
              </div>
            </div>
          )}
          
          {/* 주소 검색 바 */}
          <div className="absolute top-4 left-4 right-4 z-10">
            <div className="flex gap-2 bg-card/80 backdrop-blur-sm rounded-3xl shadow-lg border-2 border-primary/30 p-2">
              <div className="relative flex-1">
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={handleSearchKeyPress}
                  placeholder={t.common.addressSearchPlaceholder}
                  className="pr-10 border-0 focus-visible:ring-0"
                  disabled={isSearching}
                  data-testid="input-address-search"
                />
                {searchQuery && (
                  <Button
                    size="icon"
                    variant="ghost"
                    className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                    onClick={handleClearSearch}
                    data-testid="button-clear-search"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
              <Button
                size="icon"
                onClick={handleSearchAddress}
                disabled={!searchQuery.trim() || isSearching}
                className="h-10 w-10 flex-shrink-0"
                data-testid="button-search-address"
              >
                <Search className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* 플로팅 필터 버튼들 (오른쪽 하단) */}
          <div className="fixed bottom-20 right-4 flex flex-col gap-2 z-50">
            {/* 지도 확대/축소 잠금 버튼 */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="icon"
                  onClick={toggleMapLock}
                  className={`h-10 w-10 rounded-lg shadow-lg transition-all hover:shadow-2xl ${
                    isMapLocked 
                      ? 'bg-destructive hover:bg-destructive/90 border-2 border-destructive' 
                      : 'bg-primary hover:bg-primary/90 border-2 border-primary'
                  }`}
                  data-testid="button-map-lock"
                >
                  {isMapLocked ? (
                    <Lock className="h-5 w-5 text-primary-foreground" />
                  ) : (
                    <Unlock className="h-5 w-5 text-primary-foreground" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">
                <p>{isMapLocked ? "확대/축소 잠금 해제" : "확대/축소 잠금"}</p>
              </TooltipContent>
            </Tooltip>

            {/* 위치 고정 버튼 */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="icon"
                  onClick={() => {
                    const newLockState = !isLocationLocked;
                    setIsLocationLocked(newLockState);
                    
                    // 위치 고정을 활성화할 때, 현재 위치로 지도 이동
                    if (newLockState && map && currentUserLocation) {
                      const latlng = new window.kakao.maps.LatLng(currentUserLocation.lat, currentUserLocation.lng);
                      map.panTo(latlng);
                    }
                    
                    toast({
                      title: newLockState ? "위치 고정" : "위치 고정 해제",
                      description: newLockState 
                        ? "내 위치가 화면 중앙에 고정되며, 지도가 따라 움직입니다" 
                        : "지도를 자유롭게 이동할 수 있습니다",
                    });
                  }}
                  className={`h-10 w-10 rounded-lg shadow-lg transition-all hover:shadow-2xl relative ${
                    isLocationLocked 
                      ? 'bg-blue-500 hover:bg-blue-600 border-2 border-blue-500' 
                      : 'bg-muted hover:bg-muted/80 border-2 border-border'
                  }`}
                  data-testid="button-location-lock"
                >
                  {isLocationLocked ? (
                    <Lock className="h-5 w-5 text-white" />
                  ) : (
                    <Unlock className="h-5 w-5 text-muted-foreground" />
                  )}
                  {/* 상태 표시 점 */}
                  {isLocationLocked && (
                    <span className="absolute -top-1 -right-1 h-3 w-3 bg-green-400 border-2 border-white rounded-full animate-pulse" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">
                <p className="font-medium">{isLocationLocked ? "위치 고정 해제" : "위치 고정"}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {isLocationLocked 
                    ? "내 위치가 화면 중앙에 고정됩니다" 
                    : "내 위치를 화면 중앙에 고정합니다"}
                </p>
              </TooltipContent>
            </Tooltip>

            {/* 그룹 필터 버튼 */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="icon"
                  className={`h-10 w-10 rounded-lg shadow-lg relative overflow-visible transition-all hover:shadow-2xl ${
                    selectedGroupIds.includes("all") ? 'bg-primary hover:bg-primary/90 border-2 border-primary' : ''
                  }`}
                  onClick={() => setGroupFilterOpen(true)}
                  data-testid="button-group-filter"
                  style={(() => {
                    if (selectedGroupIds.includes("all")) return {};
                    
                    const colors: string[] = [];
                    selectedGroupIds.forEach(id => {
                      if (id === "personal") {
                        colors.push(PERSONAL_MEMO_COLOR);
                      } else {
                        const group = groups.find(g => g.id === id);
                        if (group) colors.push(group.color);
                      }
                    });

                    if (colors.length === 0) return {};
                    if (colors.length === 1) {
                      return { backgroundColor: colors[0], borderColor: colors[0] };
                    }

                    const step = 100 / colors.length;
                    const gradientStops = colors.map((color, index) => {
                      const start = index * step;
                      const end = (index + 1) * step;
                      return `${color} ${start}%, ${color} ${end}%`;
                    }).join(', ');

                    return {
                      background: `linear-gradient(135deg, ${gradientStops})`,
                      borderColor: colors[0]
                    };
                  })()}
                >
                  <Users className={`h-5 w-5 ${
                    selectedGroupIds.includes("all") ? 'text-primary-foreground' : ''
                  }`} style={{
                    color: selectedGroupIds.includes("all") ? undefined : 'white',
                    filter: selectedGroupIds.includes("all") ? undefined : 'drop-shadow(0 1px 2px rgba(0,0,0,0.5))'
                  }} />
                  {!selectedGroupIds.includes("all") && (
                    <Badge 
                      className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center rounded-full text-[10px] bg-white text-black border-2 border-white"
                      data-testid="badge-group-filter-count"
                    >
                      {selectedGroupIds.filter(id => id !== "all").length}
                    </Badge>
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">
                <p>그룹 필터</p>
              </TooltipContent>
            </Tooltip>

            {/* 마커 필터 버튼 */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="icon"
                  className="h-10 w-10 rounded-lg shadow-lg relative bg-primary hover:bg-primary/90 border-2 border-primary hover:shadow-2xl transition-all"
                  onClick={() => setMarkerFilterOpen(true)}
                  data-testid="button-marker-filter"
                >
                  <Filter className="h-5 w-5 text-primary-foreground" />
                  {!selectedMarkerIcons.includes("all") && (
                    <Badge 
                      className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center rounded-full text-[10px]"
                      data-testid="badge-marker-filter-count"
                    >
                      {selectedMarkerIcons.filter(icon => icon !== "all").length}
                    </Badge>
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">
                <p>카테고리 필터</p>
              </TooltipContent>
            </Tooltip>
          </div>

          {/* 마커 필터 다이얼로그 */}
          <Dialog open={markerFilterOpen} onOpenChange={setMarkerFilterOpen}>
            <DialogContent className="sm:max-w-sm" data-testid="dialog-marker-filter">
              <DialogHeader>
                <DialogTitle>마커 필터</DialogTitle>
              </DialogHeader>
              <div className="space-y-3 py-4 max-h-96 overflow-y-auto">
                <label className="flex items-center space-x-3 cursor-pointer">
                  <Checkbox
                    checked={selectedMarkerIcons.includes("all")}
                    onCheckedChange={() => {
                      onMarkerIconsChange?.(["all"]);
                    }}
                    data-testid="checkbox-marker-icon-all"
                  />
                  <div className="flex items-center flex-1">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span>{t.categories.all}</span>
                  </div>
                </label>
                {Object.entries(MARKER_ICON_COMPONENTS).map(([icon, IconComponent]) => (
                  <label key={icon} className="flex items-center space-x-3 cursor-pointer">
                    <Checkbox
                      checked={selectedMarkerIcons.includes(icon)}
                      onCheckedChange={() => {
                        if (selectedMarkerIcons.includes("all")) {
                          onMarkerIconsChange?.([icon]);
                        } else if (selectedMarkerIcons.includes(icon)) {
                          const newSelection = selectedMarkerIcons.filter(i => i !== icon);
                          onMarkerIconsChange?.(newSelection.length === 0 ? ["all"] : newSelection);
                        } else {
                          onMarkerIconsChange?.([...selectedMarkerIcons, icon]);
                        }
                      }}
                      data-testid={`checkbox-marker-icon-${icon}`}
                    />
                    <div className="flex items-center flex-1">
                      <IconComponent className="h-4 w-4 mr-2" />
                      <span>{t.categories[icon as keyof typeof t.categories]}</span>
                    </div>
                  </label>
                ))}
              </div>
            </DialogContent>
          </Dialog>

          {/* 그룹 필터 다이얼로그 */}
          <Dialog open={groupFilterOpen} onOpenChange={setGroupFilterOpen}>
            <DialogContent className="sm:max-w-sm" data-testid="dialog-group-filter">
              <DialogHeader>
                <DialogTitle>그룹 필터</DialogTitle>
              </DialogHeader>
              <div className="space-y-3 py-4 max-h-96 overflow-y-auto">
                <label className="flex items-center space-x-3 cursor-pointer">
                  <Checkbox
                    checked={selectedGroupIds.includes("all")}
                    onCheckedChange={() => {
                      onGroupIdsChange?.(["all"]);
                    }}
                    data-testid="checkbox-group-all"
                  />
                  <span>전체 그룹</span>
                </label>
                <label className="flex items-center space-x-3 cursor-pointer">
                  <Checkbox
                    checked={selectedGroupIds.includes("personal")}
                    onCheckedChange={() => {
                      if (selectedGroupIds.includes("all")) {
                        onGroupIdsChange?.(["personal"]);
                      } else if (selectedGroupIds.includes("personal")) {
                        const newSelection = selectedGroupIds.filter(id => id !== "personal");
                        onGroupIdsChange?.(newSelection.length === 0 ? ["all"] : newSelection);
                      } else {
                        onGroupIdsChange?.([...selectedGroupIds, "personal"]);
                      }
                    }}
                    data-testid="checkbox-group-personal"
                  />
                  <span>개인 메모</span>
                </label>
                {groups.filter(group => group.name !== "개인 메모").map((group) => (
                  <label key={group.id} className="flex items-center space-x-3 cursor-pointer">
                    <Checkbox
                      checked={selectedGroupIds.includes(group.id)}
                      onCheckedChange={() => {
                        if (selectedGroupIds.includes("all")) {
                          onGroupIdsChange?.([group.id]);
                        } else if (selectedGroupIds.includes(group.id)) {
                          const newSelection = selectedGroupIds.filter(id => id !== group.id);
                          onGroupIdsChange?.(newSelection.length === 0 ? ["all"] : newSelection);
                        } else {
                          onGroupIdsChange?.([...selectedGroupIds, group.id]);
                        }
                      }}
                      data-testid={`checkbox-group-${group.id}`}
                    />
                    <div className="flex items-center flex-1">
                      <div 
                        className="w-3 h-3 rounded-full flex-shrink-0 mr-2" 
                        style={{ backgroundColor: group.color }}
                      />
                      <span>{group.name}</span>
                    </div>
                  </label>
                ))}
              </div>
            </DialogContent>
          </Dialog>
        </>
      )}
    </div>
  );
}
